
  # Site para seleção de cursos

  This is a code bundle for Site para seleção de cursos. The original project is available at https://www.figma.com/design/fhGMsSl43l5PQhV3Qdbm4d/Site-para-sele%C3%A7%C3%A3o-de-cursos.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  