import { ArrowUpRight, Check } from "lucide-react";
import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback";
import courseImage from "@/imports/ChatGPT_Image_29_de_jul._de_2026__02_15_51.png";

const features = [
  "Receitas práticas e deliciosas",
  "Fáceis e rápidas de preparar",
  "Menos carboidratos, mais qualidade de vida",
  "Opções para todas as refeições",
];

export default function App() {
  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center px-4 py-10"
      style={{ fontFamily: "'Barlow', sans-serif", backgroundColor: "#0b0e11" }}
    >
      {/* Card */}
      <div
        className="w-full max-w-sm rounded-3xl overflow-hidden"
        style={{ backgroundColor: "#131920", border: "1px solid #1e2a36", boxShadow: "0 24px 64px rgba(0,0,0,0.6)" }}
      >
        {/* Cover image */}
        <div className="relative w-full" style={{ aspectRatio: "4/3" }}>
          <ImageWithFallback
            src={courseImage}
            alt="10 Receitas Low-Carb 2026 — prato com frango grelhado, brócolis e tomates"
            className="w-full h-full object-cover"
          />
          {/* Gradient overlay bottom */}
          <div
            className="absolute inset-0"
            style={{ background: "linear-gradient(to top, #131920 0%, transparent 55%)" }}
            aria-hidden="true"
          />
          {/* Badge */}
          <span
            className="absolute top-3 right-3 text-[10px] font-black uppercase tracking-widest px-3 py-1.5 rounded-full"
            style={{ backgroundColor: "#4ade80", color: "#042012" }}
          >
            Ebook Digital
          </span>
        </div>

        {/* Content */}
        <div className="px-6 pt-2 pb-6 flex flex-col gap-5">
          {/* Title */}
          <div>
            <p className="text-[10px] font-black uppercase tracking-[0.25em] mb-1.5" style={{ color: "#4ade80", opacity: 0.8 }}>
              Alimentação saudável
            </p>
            <h1
              className="text-3xl font-black uppercase leading-none tracking-tight"
              style={{ fontFamily: "'Barlow Condensed', sans-serif", color: "#e8f0e8" }}
            >
              10 Receitas<br />
              <span style={{ color: "#4ade80" }}>Low-Carb</span>
            </h1>
            <p className="text-sm font-bold mt-1" style={{ color: "#3a4a3a" }}>
              2026 — Sabor e saúde todos os dias
            </p>
          </div>

          {/* Features */}
          <ul className="flex flex-col gap-2.5">
            {features.map((f) => (
              <li key={f} className="flex items-center gap-3">
                <span
                  className="shrink-0 w-5 h-5 rounded-full flex items-center justify-center"
                  style={{ backgroundColor: "#4ade8022", border: "1.5px solid #4ade8040" }}
                >
                  <Check size={10} color="#4ade80" strokeWidth={3} />
                </span>
                <span className="text-sm font-medium" style={{ color: "#7a9a7a" }}>{f}</span>
              </li>
            ))}
          </ul>

          {/* CTA */}
          <a
            href="https://pay.cakto.com.br/3cmbn3g_1011034"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 w-full py-4 rounded-2xl font-black uppercase tracking-widest text-sm transition-all duration-150 hover:brightness-110 active:scale-[0.98]"
            style={{ backgroundColor: "#4ade80", color: "#042012" }}
          >
            Acessar agora
            <ArrowUpRight size={16} />
          </a>

          <p className="text-center text-[11px] font-medium" style={{ color: "#2a3a2a" }}>
            Acesse onde e quando quiser
          </p>
        </div>
      </div>
    </div>
  );
}
